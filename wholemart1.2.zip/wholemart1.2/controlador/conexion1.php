<?php
/*$db_host = "localhost";
$db_user = "root";
$db_pass = "WiL080102*";
$db_database = "proyecto_wholemart";
$conexion = mysqli_connect($db_host, $db_user, $db_pass, $db_database);
if ($conexion == false) {
  
    //var_dump($conexion);
   die("Error de Conexion");
}

bd wilson
$db_host = "localhost";
$db_user = "root";
$db_pass = "123456";
$db_database = "bd_wholemart";
$conexion = mysqli_connect($db_host, $db_user, $db_pass, $db_database);
if ($conexion == false) {
  
    //var_dump($conexion);
   die("Error de Conexion");
}*/

$db_host = "localhost";
$db_user = "root";
$db_pass = "123456";
$db_database = "sistemas_wholemart";
$conexion = mysqli_connect($db_host, $db_user, $db_pass, $db_database);
if ($conexion == false) {
  
    //var_dump($conexion);
   die("Error de Conexion");
}

/*$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_database = "proyecto_wholemart";
$conexion = mysqli_connect($db_host, $db_user, $db_pass, $db_database);
if ($conexion == false) {
  
    //var_dump($conexion);
   die("Error de Conexion");
}*/

?>